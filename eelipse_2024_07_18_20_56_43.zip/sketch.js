function setup() {
  createCanvas(600, 600,WEBGL);
}

function draw() {
  background(119, 195, 242);
  // Use six vertices
  ellipse(0,0,100,200,10);
  describe( 'a white hexagon on a blue canvas');
  
  ellipse(100,10,50,80)
  fill(242, 203, 119)
  
}

